#ifndef _GAMEPAD_H_
#define _GAMEPAD_H_




namespace syd {

class GamePad {

public:
	



};

}


#endif //!defined(_GAMEPAD_H_)