// $Id: WinIdle.h,v 1.1.1.1 2002/03/20 15:12:19 noname Exp $

#ifndef _SYD_WINIDLE_H_
#define _SYD_WINIDLE_H_

namespace syd {

bool WinIdle();


}// syd

#endif

