// Console.h
#ifndef __CONSOLE_H__
#define __CONSOLE_H__

namespace syd {
	bool WinCreateConsole();
	bool WinFreeConsole();
}; //syd

#endif //__CONSOLE_H__
