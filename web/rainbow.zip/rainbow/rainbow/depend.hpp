#ifndef _DEPEND_HPP_
#define _DEPEND_HPP_
 
namespace syd{
	class Window;
}


namespace depend{

syd::Window* new_window();

} // namespace depend;

#endif //!defined(_DEPEND_HPP_)
