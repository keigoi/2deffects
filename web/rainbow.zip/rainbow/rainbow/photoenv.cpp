#include "photoenv.hpp"


namespace raytrace {


} // namespace raytrace


